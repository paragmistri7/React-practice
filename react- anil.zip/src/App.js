import {User} from './User'
import Classcompo from './classcompo';
import Clickevent from './Clickevent';
import Statecfunction from './statefunctioncompo.js';
import Stateclass from './stateclass'
import Propsfun from './propsfunction';
import Propsclass from './propsclass';
import Getinput from './getinput';
import Hides from './hideshowtoggle';
import Handleform from './handleform';
import Conren from './conditionrendering';
import Bform from './basicformvalidation';
import Passfun from './passfunctionasprops';
import Constructorcompo from './constructor';
import Rendersss from './render';
import Didmount from './componentdidmount';
import Didupdate from './componentdidupdate';
import Shouldupdate from './componentshouldupdate';
import Unmountcompo01 from './componentunmount';
import Hooksdef from './component01/hooksdef'
import Useeffect from './component01/useeffecthooks';
import Useeffect03 from './component01/useeffectsateprops';
import Useeffect033 from './component01/useeffect01stateprops';
import Stylecompo from './component01/style';
import BootstrapExample from './bootstrap';
import Arraylisting from './arraylistingwithmapfun';
import Bootexample from './listbootstraptable';
import Reusecompo from './reusecompo';
import Lifting from './component01/lifting';
import Purecompo from './purecomponent';
import Purepropcompo from './purecompoprops';
import Memocompo from './component01/usememo';
import Refcompo from './component01/ref';
import Userefcompo from './component01/useref';
import Forwardr from './component01/forwardref';
import Controll from './component01/controlledcompo';
import Uncontro from './component01/uncontrollcompo';
import HOCcompo from './component01/HOC';
import Fetchapicompo from './component01/fetchapicompo';
import Postapi from './component01/postapi';
import Previousstate from './component01/previous state fun';
import Previousprops from './component01/previousprops';
import Stateobj from './component01/state with object';
import Appcontext from './component02/02app';


import Homecontainer from './redux/container/homecontainer'






function App() {
    function Passfunction() {
        return (
          alert("hello")
      )    
  }

      return (
        <>
            {/* <h1> large... </h1> */}
            {/* <User/> */}
            {/* <Classcompo /> */}
            {/* <Clickevent /> */}
            {/* <Statecfunction /> */}
            {/* <Stateclass /> */}
            {/* <Propsfun /> */}
            {/* <Propsclass /> */}
            {/* <Getinput/> */}
            {/* <Hides/> */}
            {/* <Handleform/> */}
            {/* <Conren /> */}
            {/* <Bform/> */}
            {/* <Passfun  data = {Passfunction} /> */}
            {/* <Constructorcompo/> */}
            
            {/* <Rendersss/> */}
            {/* <Didmount/> */}
            {/* <Didupdate/> */}
            {/* <Shouldupdate /> */}
            {/* <Unmountcompo01 /> */}
            {/* <Hooksdef /> */}
          {/* <Useeffect /> */}
          {/* <Useeffect03 /> */}
          {/* <Useeffect033 /> */}
          {/* <Stylecompo /> */}
          {/* <BootstrapExample/> */}
          {/* <Arraylisting/>2 */}
          {/* <Bootexample /> */}
          {/* <Reusecompo /> */}
          {/* <Lifting /> */}
          {/* <Purecompo/> */}
          {/* <Purepropcompo /> */}
          {/* <Memocompo /> */}
          {/* <Refcompo /> */}
          {/* <Userefcompo /> */}
          {/* <Forwardr/> */}
          {/* <Controll/> */}
          {/* <Uncontro/> */}
          {/* <HOCcompo /> */}
          {/* <Fetchapicompo /> */}
          {/* <Postapi/> */}
          {/* <Previousstate/> */}
          {/* <Previousprops/> */}
          {/* <Stateobj /> */}
          {/* <Appcontext /> */}
          
          <Homecontainer/>
         


        </>
    )
}
export default App;