function Reuse01compo(prb) {
    return (
        <>
            <div>
                <span>{prb.data.name}</span>
                <span>{prb.data.email}</span>
                <span>{prb.data.contact}</span>
            </div>

        </>
    )
}
export default Reuse01compo 