// import React, { Component } from "react";

import React from "react";

export default  class Classcompo extends React.Component {
    render() {
        return (
            <>
                <h2>hey whats up...</h2>
            </>
        )
    }
}
// export default Classcompo;