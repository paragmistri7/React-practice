
export function User() {
    function Nwe() {
        return (<h3>function in function  </h3>)
    }
    return (
        <>
            <h2>hello</h2>
            
            {/* <Nwe></Nwe> */}
            {Nwe()}
        </>
    )
}
// export default User;