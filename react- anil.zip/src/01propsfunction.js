function Prop01(pr) {
    return (
        <>
            <h2>name : {pr.nam}</h2>
            <h4>email : {pr.email}</h4>
            <h4>Addresss :{pr.other.add} </h4>
            <br></br>
        </>
    )
}
export default Prop01